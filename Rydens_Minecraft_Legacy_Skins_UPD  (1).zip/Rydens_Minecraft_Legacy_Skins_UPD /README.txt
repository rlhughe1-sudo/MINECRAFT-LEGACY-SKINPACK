RYDEN'S MINECRAFT LEGACY SKINS

Packs included from user-supplied archives:
- 4th Birthday Skin Pack: 20 skin textures, 0 cape textures
- Skin Pack 6: 45 skin textures, 1 cape textures
- 1st Birthday Skin Pack: 23 skin textures, 1 cape textures
- Power Rangers Skin Pack: 20 skin textures, 0 cape textures
- Marvel Spider-Man Skin Pack: 35 skin textures, 6 cape textures
- Halo Mash-Up Pack: 48 skin textures, 1 cape textures
- Nightmare Before Christmas Mash-Up Pack: 40 skin textures, 0 cape textures
- Halloween 2015 Mash-Up Pack: 43 skin textures, 7 cape textures
- Festive Skin Pack: 24 skin textures, 0 cape textures
- Festive Mash-Up Pack: 44 skin textures, 0 cape textures
- Fallout Mash-Up Skin Pack: 44 skin textures, 0 cape textures
- Adventure Time Mash-Up Pack: 51 skin textures, 2 cape textures
- Skin Pack 1 (PS3): 44 skin textures, 0 cape textures
- 2nd Birthday Skin Pack (PS3): 24 skin textures, 2 cape textures

Total skin textures: 505
Total cape textures: 20

Original PNG texture files are preserved from the supplied ZIP archives.
Filenames are preserved (some archives use numbered dlcskin/dlccape names, others use character names).
Capes are kept in a Capes/ subfolder inside each pack.
Character names and creator credits have not been inferred.
(PS3) marks packs taken from the PlayStation 3 Edition archives; Mash-Up and Festive/Halloween packs come from Wii U Edition archives.
This is a partial collection and does not yet include every item from the Planet Minecraft collection.
